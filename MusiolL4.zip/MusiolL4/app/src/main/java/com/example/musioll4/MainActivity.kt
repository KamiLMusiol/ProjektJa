package com.example.musioll4

import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {



        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
/*
        val p = findViewById<Button>(R.id.p)

       p.setOnClickListener {


            val e = findViewById<EditText>(R.id.e)
            var m : String

            if(e.text.trim().isEmpty())
            {
                m = "Najpierw sie przedstaw "

            }
            else
                m =  "Witaj " + e.text

            Toast.makeText(applicationContext, m, Toast.LENGTH_SHORT).show()

        }
        */

            val makeAddition = findViewById<Button>(R.id.add)
            val makeSubstraction = findViewById<Button>(R.id.sub)


            val im1 = findViewById<EditText>(R.id.Im1)
            val im2 = findViewById<EditText>(R.id.Im2)
            val re1 = findViewById<EditText>(R.id.Re1)
            val re2 = findViewById<EditText>(R.id.Re2)

        // cz 2
        val sp = findViewById<Spinner>(R.id.sth)


        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("+", "-"))

        sp.adapter = adapter



            fun createOdp( odp1: Double, odp2: Double)
            {

                var odp: String
                if(odp2 < 0)
                {

                     odp = "$odp1$odp2" + "i"
                }
                else
                 odp = "$odp1+$odp2" + "i"
                Toast.makeText(applicationContext, odp,  Toast.LENGTH_SHORT).show()
            }


        fun error1()
        {

            Toast.makeText(applicationContext, "Brak wartosci",  Toast.LENGTH_SHORT).show()
        }

        fun checking() : Boolean
        {
            if(re1.text.isEmpty() || re2.text.isEmpty() || im1.text.isEmpty() || im2.text.isEmpty() )
            {
                error1()
                return true;
            }
            return false;


        }

            fun error2()
            {

                Toast.makeText(applicationContext, "Masz podac liczby!",  Toast.LENGTH_SHORT).show()
            }



       sp.onItemSelectedListener
        {
            val selected = sp.selectedItem.toString()
            Toast.makeText(applicationContext, "Masz podac liczby!",  Toast.LENGTH_SHORT).show()
            if(selected == "+")
            {
                if(!checking())
                {
                    try {
                        var re = re1.text.toString().toDouble() +re2.text.toString().toDouble() as Double
                        var im = im1.text.toString().toDouble() +im2.text.toString().toDouble() as Double

                        createOdp(re, im)


                    }
                    catch( e: NumberFormatException){
                        error2()
                    }
                }
            }
            else{

                if(!checking())
                {
                    try {
                        var re = re1.text.toString().toDouble() -re2.text.toString().toDouble() as Double
                        var im = im1.text.toString().toDouble() -im2.text.toString().toDouble() as Double

                        createOdp(re, im)


                    }
                    catch( e: NumberFormatException){
                        error2()
                    }
                }

            }
        }



    makeAddition.setOnClickListener {
        if(!checking())
        {
            try {
                var re = re1.text.toString().toDouble() +re2.text.toString().toDouble() as Double
                var im = im1.text.toString().toDouble() +im2.text.toString().toDouble() as Double

                createOdp(re, im)


            }
            catch( e: NumberFormatException){
                error2()
            }
        }


    }

        makeSubstraction.setOnClickListener {
            if(!checking())
            {
                try {
                    var re = re1.text.toString().toDouble() -re2.text.toString().toDouble() as Double
                    var im = im1.text.toString().toDouble() -im2.text.toString().toDouble() as Double

                    createOdp(re, im)


                }
                catch( e: NumberFormatException){
                    error2()
                }
            }


        }







    }
}